.. SPDX-License-Identifier: CC-BY-SA-4.0
.. Getting started information is defined in the project README file.
.. include:: ../README.rst
   :start-after: .. section-begin-getting-started
   :end-before: .. section-end-getting-started
