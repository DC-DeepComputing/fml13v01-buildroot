.. SPDX-License-Identifier: CC-BY-SA-4.0

.. _api:

API
===

:: Placeholder for Doxygen documentation
